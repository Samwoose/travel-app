// import { urlValidator } from './js/urlChecker'
// import { handleSubmit } from './js/formHandler'
// import './styles/resets.scss'
// import './styles/base.scss'
// import './styles/footer.scss'
// import './styles/form.scss'
// import './styles/header.scss'
import './styles/style.scss'
import { dataUploader } from './js/app'
import { postNameOfCityNDate } from './js/app'
import { dateRestrictor } from './js/app'
import { numOfDaysCalculator} from './js/daysCalculator'
export{
    dataUploader,
    postNameOfCityNDate,
    dateRestrictor,
    numOfDaysCalculator
}

// export {
//     urlValidator,
//     handleSubmit
// }
